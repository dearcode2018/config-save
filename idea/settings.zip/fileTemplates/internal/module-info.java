#parse("File Header.java")
 /**
 * @description 
 * @author qianye.zheng
 * ${MODULE_NAME}
 */
module #[[$MODULE_NAME$]]# {
}